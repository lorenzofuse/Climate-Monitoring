***********************************************************************************
PROGETTO CLIMATE MONITORING
LABORATORIO A, CORSO DI LAUREA TRIENNALE IN INFORMATICA - UNIVERSITA' DEGLI STUDI DELL'INSUBRIA

PROGETTO REALIZZATO DA: 

Lorenzo Fusè - 753168
lfuse1@studenti.uninsubria.it

Alessandro Ciminella - 753369
aciminella@studenti.uninsubria.it

Cosmin Dragan - 754427
cdragan@studenti.uninsubria.it


***********************************************************************************
CONTENUTI DELL'ARCHIVIO

- File .zip o cartella compressa ClimateMonitoring contiene le cartelle con i file sorgenti
 (.java), i file *.class e il file .pom
- Documentazione javadoc del progetto
-Manuale Tecnico 
-Manuale Utente
-file README.txt
-file AUTORI.txt

***********************************************************************************
REQUISITI
L'applicazione richiede Java JDK 17.

NOTA: L'applicazione è stata sviluppata e testata su Windows 11 e MacOS con
l'utilizzo di Eclipse 2023-09 e Intellj IDEA CE,  tuttavia l’applicativo contiene tutte le librerie
necessarie anche per il sistema operativo Linux (non è garantito il corretto funzionamento)

***********************************************************************************
AVVIARE L'APPLICAZIONE
Visionare AVVIAMENTO APPLICAZIONE sul manuale utente.
ClimateMonitoring/ClimateMonitoring/ClimateMonitoring
